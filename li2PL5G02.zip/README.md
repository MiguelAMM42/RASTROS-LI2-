# RASTROS-LI2-

- UC : LI2;

- TURNO PRÁTICO: PL5;

- GRUPO : 1;

- ALUNOS:
	- Diogo Manuel Brito Pires @a93239;	
	- Gonçalo André Rodrigues Soares @a93286;
    - Miguel Ângelo Machado Martins @a93280;
